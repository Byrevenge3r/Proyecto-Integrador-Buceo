package com.dam.proyectointegradorbuceo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    FirebaseAuth fAuth;
    FirebaseUser fUser;

    EditText etEmail;
    EditText etPwd;
    Button btnAcc;
    Button btnReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        fAuth = FirebaseAuth.getInstance();
        fUser = fAuth.getCurrentUser();

        etEmail = findViewById(R.id.etMail);
        etPwd = findViewById(R.id.etPassword);
        btnAcc = findViewById(R.id.btnAcceder);
        btnReg = findViewById(R.id.btnRegistrar);

        btnAcc.setOnClickListener(this);
        btnReg.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.equals(btnAcc)) {
            acceder();
        } else if (v.equals(btnReg)) {
            registrar();
        }
    }

    private void registrar() {
        String email = etEmail.getText().toString().trim();
        String pwd = etPwd.getText().toString();

        if (email.isEmpty() || pwd.isEmpty()) {
            Snackbar.make(btnAcc, R.string.no_data, Snackbar.LENGTH_LONG)
                    .show();

        } else {
            fAuth.createUserWithEmailAndPassword(email, pwd)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                fUser = fAuth.getCurrentUser();
                                Toast.makeText(LoginActivity.this,
                                        getString(R.string.msj_registrado),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(LoginActivity.this,
                                        getString(R.string.msj_no_registrado),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        }
    }


    private void acceder() {
        String email = etEmail.getText().toString().trim();
        String pwd = etPwd.getText().toString();
        if (email.isEmpty() || pwd.isEmpty()) {
            Toast.makeText(LoginActivity.this, R.string.no_data, Toast.LENGTH_LONG).show();

        } else {
            fAuth.signInWithEmailAndPassword(email, pwd)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                fUser = fAuth.getCurrentUser();
                                Intent i = new Intent(LoginActivity.this,
                                        MainActivity.class);
                                i.putExtra("EMAIL", fUser.getEmail());
                                startActivity(i);
                                finish();
                            } else {
                                Toast.makeText(LoginActivity.this,
                                        getString(R.string.msj_no_accede),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        }
    }
}