package com.dam.proyectointegradorbuceo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.NavHostController;
import androidx.navigation.fragment.NavHostFragment;

import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarMenu;

public class MenuActivity extends AppCompatActivity {

    BottomNavigationView bottomNavView;
    NavController navcontroller;
    Fragment fragmentContainerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        bottomNavView = findViewById(R.id.bottomNavView);

        NavHostFragment.findNavController(fragmentContainerView);


    }

}